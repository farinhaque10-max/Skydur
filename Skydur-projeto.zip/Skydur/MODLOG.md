# Skydur development journal

## Agreed design
BG3 is the primary game. The creator wants Skyrim-like camera and action RPG gameplay, selected the small sword/block/stamina encounter, and authorized MIT code with remixes. Single player is the recommended default, not an explicit creator answer. Camera mode switching remains a proposed implementation detail.

## Recon evidence
- Melty connection works through authenticated HTTPS. Token is read from the uploaded prompt, never saved into project files.
- `game_info` confirms Melty automatically installs BG3 Script Extender. Proposed host integration route: its APIs where sufficient; camera/action combat are NOT verified capabilities.
- Skyrim must contribute real installed data. No extracted game content may be copied into this repository, release, or other game folder.
- `search_mashups` found Baldur's Skyrim, an inverse-direction mashup. `mashup_info` says remixes disabled and recipe withheld. No code or recipe reused.
- `list_my_mods` found Force & Initiative; not established as this project, so untouched.
- universal-modder cloned to `/workspace/universal-modder`; CLI dependencies installed with `UV_CACHE_DIR=/tmp/skydur-uv-cache` because home cache is read-only.
- `um scan --list` found no Steam/Epic/Xbox installations. Targeted filename search found no installed games in accessible workspace, home, mounts or opt paths; `/opt/containerd` is inaccessible, so no global absence claim.
- This machine is Linux, not the creator's Windows PC. Toolkit Windows automation supports native Windows/WSL; no PC-control connection is available.
- Official Norbyte/bg3se source cloned to `/tmp/skydur-bg3se` for API investigation; it is not game content.

## Build gate
Sheets are the source of truth. `python3 tools/preflight.py` must report unverified and unfilled cells as failures. Do not build a pretend game, invent APIs, or report these design sheets as a working mod. No build, install recipe, gameplay media or Melty release exists yet.

## Next prerequisite
Continue this project in a Windows/WSL coding session on the machine with the creator's licensed BG3 and Skyrim SE installations, or provide an authorized remote PC-control tool. Discover real install paths and game versions there. Back up saves before modded launches. Verify camera, direct movement and real-time combat independently in BG3 before widening scope; inspect only relevant Skyrim settings in place. Do not replace BG3 as host without creator agreement.

## Publication
Keep everything draft-only until real gameplay, complete one-click recipe, media and Melty installation tests pass. Ask for publication authorization after providing the concrete tested result. Code license: MIT; game content remains under the games' own terms. No git commit or push has been performed.
