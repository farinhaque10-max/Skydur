"""Report incomplete system cells. This checks design completeness, not gameplay."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
document = json.loads((root / "design/systems.json").read_text())
required = ("id", "behavior", "source", "verification", "evidence")
issues = []
seen = set()
for index, row in enumerate(document["rows"]):
    name = row.get("id", f"row[{index}]")
    if name in seen:
        issues.append(f"{name}: duplicate id")
    seen.add(name)
    for column in required:
        if row.get(column) in (None, ""):
            issues.append(f"{name}.{column}: unfilled")
    if row.get("verification") != "verified":
        issues.append(f"{name}.verification: not verified")
for issue in issues:
    print(issue)
print(f"{len(document['rows'])} systems; {len(issues)} unresolved cells/checks")
raise SystemExit(1 if issues else 0)
